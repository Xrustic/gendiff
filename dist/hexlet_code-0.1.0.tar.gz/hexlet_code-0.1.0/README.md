### Hexlet tests and linter status:
[![Actions Status](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-50/actions)

### Build Status
[![Build Status](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg?branch=master)](https://github.com/Xrustic/python-project-50/actions)

### Github Actions
[![hexlet-check](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml)

Аскинема 3 части проекта (Сравнение плоских файлов JSON):
<a href="https://asciinema.org/a/OfiBUlZDiVoI1L8cTaJWqrACh" target="_blank"><img src="https://asciinema.org/a/OfiBUlZDiVoI1L8cTaJWqrACh.svg" /></a>
