from gendiff.gendiff import gen_diff


__all__ = ('gen_diff',)
