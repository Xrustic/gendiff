from gendiff.gendiff_file import gen_diff


__all__ = ('gen_diff',)
