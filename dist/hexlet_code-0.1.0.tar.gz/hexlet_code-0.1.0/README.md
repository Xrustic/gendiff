### Hexlet tests and linter status
[![Actions Status](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-50/actions)

### Build Status
[![Build Status](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg?branch=master)](https://github.com/Xrustic/python-project-50/actions)

### Github Actions
[![hexlet-check](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Xrustic/python-project-50/actions/workflows/hexlet-check.yml)

### Maintainability Badge
<a href="https://codeclimate.com/github/Xrustic/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/677257c31e98d01739bd/maintainability" /></a>

### Test Coverage Badge
<a href="https://codeclimate.com/github/Xrustic/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/677257c31e98d01739bd/test_coverage" /></a>

Аскинема 3 части проекта (Сравнение плоских файлов JSON):
<a href="https://asciinema.org/a/OfiBUlZDiVoI1L8cTaJWqrACh" target="_blank"><img src="https://asciinema.org/a/OfiBUlZDiVoI1L8cTaJWqrACh.svg" /></a>

Аскинема 5 части проекта (Сравнение плоских файлов YAML):
<a href="https://asciinema.org/a/LG7mjBnovSKFx5tKBB9b4Hc9E" target="_blank"><img src="https://asciinema.org/a/LG7mjBnovSKFx5tKBB9b4Hc9E.svg" /></a>

Аскинема 6 части проекта (Рекурсивное сравнение):
<a href="https://asciinema.org/a/z9Ovu1CkdcciN4wActSRUUGc4" target="_blank"><img src="https://asciinema.org/a/z9Ovu1CkdcciN4wActSRUUGc4.svg" /></a>
