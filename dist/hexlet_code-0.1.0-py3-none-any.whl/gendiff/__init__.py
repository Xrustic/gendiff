from gendiff.gendiff_file import generate_diff


__all__ = ('generate_diff',)
